CREATE PROC [dbo].[ProcSumByPurchase]
(
	@Pro_name nvarchar(50),
	@Goo_name nvarchar(50)
)
AS
BEGIN
	SELECT Sell_num 总销售量
	FROM Sell INNER JOIN Goods
	ON Sell.Goo_no=Goods.Goo_no
	WHERE Goo_name=@Goo_name and Pro_name=@Pro_name and month(Sell_date)=1
END

go

