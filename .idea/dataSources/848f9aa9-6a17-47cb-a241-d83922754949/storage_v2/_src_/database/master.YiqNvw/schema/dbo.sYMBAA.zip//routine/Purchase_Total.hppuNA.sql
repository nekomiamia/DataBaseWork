CREATE FUNCTION [dbo].[Purchase_Total]
(
	@Begin_date datetime,
	@End_date datetime
)
RETURNS TABLE
AS
RETURN(
	SELECT * FROM Purchase
	WHERE Pur_date>=@Begin_date and Pur_date<=@End_date
)
go

