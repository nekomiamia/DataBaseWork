CREATE PROC [dbo].[proc_GNO]
(
	@Pro_name nvarchar(50),
	@Goo_name nvarchar(50),
	@Goo_no char(8) output
)
AS
BEGIN
SELECT @Goo_no=Goo_no
FROM Goods
WHERE Pro_name=@Pro_name and Goo_name=@Goo_name
END
go

