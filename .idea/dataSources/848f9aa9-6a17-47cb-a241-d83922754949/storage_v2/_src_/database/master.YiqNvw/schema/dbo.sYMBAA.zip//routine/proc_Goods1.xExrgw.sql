CREATE PROC [dbo].[proc_Goods1]
	@Pro_name nvarchar(20)
AS
BEGIN
	SELECT Goo_no,Goo_name,Pro_name
	FROM Goods
	WHERE Pro_name=@Pro_name
END
go

