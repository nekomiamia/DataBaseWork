CREATE PROC [dbo].[proc_Purchase1]
(	
	@Emp_name nvarchar(20)
	)
AS
IF NOT EXISTS(SELECT *
				FROM Purchase
				WHERE Emp_no IN (SELECT Emp_no
									FROM Employees
									WHERE Emp_name=@Emp_name))
BEGIN
	PRINT'无该员工所进商品信息'
	RETURN 1
END
ELSE
BEGIN
	SELECT Pur_no,Pur_price,Pur_num,Pur_date,Goo_no,Emp_no
	FROM Purchase
	WHERE Emp_no IN(SELECT Emp_no
						FROM Employees
						WHERE Emp_name=@Emp_name)
END
go

