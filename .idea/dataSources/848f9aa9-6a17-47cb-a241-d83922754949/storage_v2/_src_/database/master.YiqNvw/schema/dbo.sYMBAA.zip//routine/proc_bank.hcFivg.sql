CREATE PROC [dbo].[proc_bank]
@A nvarchar(50),
@B nvarchar(50),
@money money
AS
BEGIN
DECLARE @now_money money
SELECT @now_money=money
FROM bank
WHERE name=@A
IF((@now_money-@money)<0)
BEGIN
BEGIN TRAN fail
	UPDATE bank
	SET money=money-@money
	WHERE name=@A
	UPDATE bank
	SET money=money+@money
	WHERE name=@B
	PRINT'余额不足转账失败'
	ROLLBACK TRAN fail
END
ELSE
BEGIN
BEGIN TRAN success
	UPDATE bank
	SET money=money-@money
	WHERE name=@A
	UPDATE bank
	SET money=money+@money
	WHERE name=@B
	PRINT @A+'向'+@B+'转账'+convert(nvarchar,@money)+'元'
	COMMIT
END
END
go

