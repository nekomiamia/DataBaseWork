CREATE PROC [dbo].[proc_emp_grant]
@Emp_name nvarchar(50)
AS
BEGIN
DECLARE @view nvarchar(255)
DECLARE @str nvarchar(255)
IF EXISTS(SELECT * FROM Purchase
			WHERE Emp_no IN(SELECT Emp_no FROM Employees
								WHERE Emp_name=@Emp_name))
BEGIN
	INSERT INTO login VALUES(@Emp_name,'123456')
	SET @view='V_'+@Emp_name
	SET @str='CREATE VIEW '+@view+
	' AS
	SELECT * FROM Purchase
	WHERE Emp_no IN(SELECT Emp_no FROM Employees
								WHERE Emp_name='''+@Emp_name+''')'
	EXEC(@str)
	EXEC SP_ADDLOGIN @Emp_name,'123456'
	EXEC SP_GRANTDBACCESS @Emp_name,@Emp_name
	SET @str='GRANT SELECT,UPDATE ON '+@view+' TO '+@Emp_name
	EXEC(@str)
	SET @str='GRANT SELECT ON Purchase TO '+@Emp_name
	EXEC(@str)
END
ELSE
	RETURN 1;
END
go

