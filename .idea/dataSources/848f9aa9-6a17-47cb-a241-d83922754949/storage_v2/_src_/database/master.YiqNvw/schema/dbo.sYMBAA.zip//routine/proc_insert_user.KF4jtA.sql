CREATE PROC [dbo].[proc_insert_user]
(
	@uname varchar(20),
	@sex	char(2),
	@Upassword	varchar(32)
)
AS
BEGIN
	SET @Upassword=(SELECT SUBSTRING(sys.fn_sqlvarbasetostr(HashBytes('MD5',@Upassword)),3,32))
	INSERT INTO users VALUES(@uname,@sex,@Upassword)
END
go

