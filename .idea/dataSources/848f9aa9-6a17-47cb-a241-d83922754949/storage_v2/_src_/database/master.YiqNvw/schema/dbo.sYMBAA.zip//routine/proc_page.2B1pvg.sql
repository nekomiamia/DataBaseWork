CREATE PROC [dbo].[proc_page]
(
	@Begin_no int,
	@End_no int
)
AS
BEGIN
	SELECT TOP (@End_no) *
	FROM Purchase EXCEPT
	SELECT TOP (@Begin_no-1) *
	FROM Purchase 
END
go

