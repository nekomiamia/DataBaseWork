CREATE VIEW [dbo].[V1]
AS
SELECT * FROM Employees
WHERE Dep_no in(SELECT Dep_no
					FROM Department
					WHERE Dep_name='采购部')
go

