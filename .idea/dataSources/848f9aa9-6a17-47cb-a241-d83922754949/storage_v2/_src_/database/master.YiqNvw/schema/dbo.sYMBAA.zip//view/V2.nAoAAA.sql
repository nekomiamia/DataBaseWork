CREATE VIEW [dbo].[V2]
AS
SELECT Emp_no,Emp_name
FROM Employees
go

