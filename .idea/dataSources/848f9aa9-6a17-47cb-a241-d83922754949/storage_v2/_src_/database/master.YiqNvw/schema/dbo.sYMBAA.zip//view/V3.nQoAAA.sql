CREATE VIEW [dbo].[V3]
AS
SELECT * FROM Purchase
WHERE Emp_no in(SELECT Emp_no 
					FROM Employees
					WHERE Emp_name='张明')
go

