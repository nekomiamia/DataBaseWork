CREATE VIEW [dbo].[V_王燕] AS
	SELECT * FROM Purchase
	WHERE Emp_no IN(SELECT Emp_no FROM Employees
								WHERE Emp_name='王燕')
go

